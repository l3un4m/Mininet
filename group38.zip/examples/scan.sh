internet python3 attack/scan.py 10.12.0.0/24 #Perform Scan
