internet python3 attack/dns.py 10.1.0.2 10.12.0.20 5353 #Perform Attack
